import src.Main

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    src.Main.Main().start()
