

class EmptyFileException(Exception):
    pass

class NegativeNumberException(Exception):
    pass

class OutOfRangeException(Exception):
    pass